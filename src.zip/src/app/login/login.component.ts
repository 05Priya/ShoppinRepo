import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
name:string ='admin';
pass:string = 'adminn';
  constructor() { }
submit(username,psw){
    if(username==name && psw==pass)
    {
       
    }
    else{
        
    }
}
  ngOnInit() {
  }

}
